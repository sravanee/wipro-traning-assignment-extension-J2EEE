package com.wipro.controller;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.bean.ChangeBean;
import com.wipro.dao.ChangeDao;


/**
 * Servlet implementation class ChangeServlet
 */
@WebServlet("/ChangeServlet")
public class ChangeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			PrintWriter out = response.getWriter();
			String userName = request.getParameter("uname");
	        String oldpwd=request.getParameter("password");
	        String newpwd=request.getParameter("newpwd");
	        
	        
	        ChangeBean changeBean = new ChangeBean();
			changeBean.setUserName(userName);
			changeBean.setPassword(oldpwd);
			changeBean.setnewPassword(newpwd);
	        
			ChangeDao dao = new ChangeDao();
			String status = dao.checkUser(changeBean);
			
			if(status.equals("Success"))
			{
				out.println("<font color=green><b>Password changed</b></font><br><br><br>");
				out.println("<b>Please <a href=\"Login.jsp\">log-in</a> to continue.</b>");
			}
			else{
				out.println("<font color=red><b>Password doesnot Change..Try Again�</b></font>");
			}
			out.close();
	        
	}

	

}
