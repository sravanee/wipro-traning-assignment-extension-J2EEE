package com.wipro.bean;
 
public class RegisterBean {

 private String username;
 private String password;
 public RegisterBean() {
 }
 public String getUserName() {
 return username;
 }
 public void setUserName(String username) {
 this.username = username;
 }
 public String getPassword() {
 return password;
 }
 public void setPassword(String password) {
 this.password = password;
 }
 
}