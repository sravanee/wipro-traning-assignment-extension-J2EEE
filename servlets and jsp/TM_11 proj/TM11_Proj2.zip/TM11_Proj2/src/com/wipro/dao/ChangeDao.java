package com.wipro.dao;

import java.sql.*;

import com.wipro.bean.ChangeBean;
import com.wipro.util.DBUtil;

public class ChangeDao {
public String checkUser(ChangeBean changeBean){
String status = "Fail";
try{
String sql = "update user_table set password= ? where username=? and password= ?";
Connection con = DBUtil.getConnection();
PreparedStatement st = con.prepareStatement(sql);

st.setString(1,changeBean.getnewPassword());
st.setString(2, changeBean.getUserName());
st.setString(3, changeBean.getPassword());

int i= st.executeUpdate();

if (i!=0)  //Just to ensure data has been inserted into the database
status = "Success"; 


st.close();
con.close();
}
catch(Exception e){e.printStackTrace();}
return status;
}
}
