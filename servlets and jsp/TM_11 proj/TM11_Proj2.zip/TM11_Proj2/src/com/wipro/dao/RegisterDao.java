package com.wipro.dao;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.wipro.bean.RegisterBean;
import com.wipro.util.DBUtil;
 
public class RegisterDao { 
     public String registerUser(RegisterBean registerBean)
     {
        
         String username = registerBean.getUserName();
         String password = registerBean.getPassword();
         
         PreparedStatement preparedStatement = null;         
         try
         {
        	 Connection con = DBUtil.getConnection();
             String query = "insert into user_table(username,password) values (?,?)"; //Insert user details into the table 'USERS'
             preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
             
             preparedStatement.setString(1, username);
             preparedStatement.setString(2, password);
             
             int i= preparedStatement.executeUpdate();
             
             if (i!=0)  //Just to ensure data has been inserted into the database
             return "SUCCESS"; 
         }
         catch(SQLException e)
         {
            e.printStackTrace();
         }       
         return "Oops.. Something went wrong there..!";  // On failure, send a message from here.
     }
}